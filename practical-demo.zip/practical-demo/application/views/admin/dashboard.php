
	<!-- Start content -->
	<div class="content">
	<div class="container">

	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">

		<ol class="breadcrumb pull-right">
		<li><a href="#">Front Link</a></li>                                    
		<li class="active">Dashboard</li>
		</ol>
		<h4 class="pull-left">Welcome!</h4>
		</div>
	</div>
		