﻿

				<tr>
				<td><?php echo $htmldata['AdsType'];?></td>
				<td><?php echo $htmldata['AdsType'];?></td>
				<td><?php echo $htmldata['AdsType'];?></td>
				<td><?php echo $htmldata['AdsType'];?></td>
				<td><?php echo $htmldata['AdsType'];?></td>
				</tr>
				

