

	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">

		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="panel panel-default">
				<div class="panel-heading"><h3 class="panel-title">Update seconds</h3></div>
					<div class="panel-body">
						<div class="form">
						
						<form class="cmxform form-horizontal tasi-form" id="commentForm" method="post" action="<?php echo base_url('admin/serviceads/updateorderlist/'.$id);?>" novalidate="novalidate">
							
							<div class="form-group">
								<label for="cname" class="control-label col-lg-2">Order By</label>
								<div class="col-lg-6">						
									<input class="form-control" id="order" name="order" placeholder="Order" type="text">
								</div>
							</div>
							<div class="form-group">
								<label for="cname" class="control-label col-lg-2"></label>
								
								<div class="col-lg-4">
									<button class="btn btn-success waves-effect waves-light" type="submit">Add</button>
									
								</div>
							</div>
							
						</form>

						
						</div> <!-- .form -->
					</div> <!-- panel-body -->
			</div> <!-- panel -->
		</div> <!-- col -->
	</div> <!-- End row -->


<!-- Form-validation -->
						
						
		

